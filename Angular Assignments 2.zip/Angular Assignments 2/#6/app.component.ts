import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  styles: [`
    .app {
      border: 2px solid #009826;
      display: block;
      text-align: center;
      padding: 25px;
      background: #f5f5f5;
    } 
  `],
  template: `
    <div class="app">
      Parent: {{ myCount + myCount1}}
      <counter
        [count]="myCount"
        [count1]="myCount1"
        (change)="countChange($event)"
        (change1)="countChange1($event)">
      </counter>
    </div>`     
})
export class AppComponent {
  myCount: number = 7;
  myCount1: number = 3;
  
  countChange(event : any) {
    this.myCount = event; 
  }
  countChange1(event1 : any) {
    this.myCount1 = event1; 
  }
}