import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  styles: [`
    .app {
      display: block;
      text-align: center;
      padding: 25px;
      background: #f5f5f5;
      border: 2px solid red;
    }
  `],
  //this is inline template
  template: `
    <div class="app">
      Couter
      <counter [mycounter]="mycounter1"></counter>
    </div>
  `// <counter [count]="initialCount" [mincount]="0" [maxcount]="20"></counter>
})
export class AppComponent {
  //initialCount: number = 10;
  mycounter1: number = 0;
}


