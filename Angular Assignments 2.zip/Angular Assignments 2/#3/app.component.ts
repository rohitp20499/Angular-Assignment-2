import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  styles: [`
    .app {
      display: block;
      text-align: center;
      padding: 25px;
      background: #f5f5f5;
      border: 2px solid red;
    }
  `],
  //this is inline template
  template: `
  <counter [count]="initialCount" [mincount]="0" [maxcount]="20"></counter>  
  `
  // <div class="app">
  //     Couter
  //     <counter [mycounter]="mycounter1"></counter>
  //   </div>
})
export class AppComponent {
  initialCount: number = 10;
  // mycounter1: number = 0;
}



//que 3 ans