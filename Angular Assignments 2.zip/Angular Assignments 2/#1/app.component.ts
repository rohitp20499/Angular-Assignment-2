import { Component } from '@angular/core';
import { bufferToggle } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles:[
    '.blue{color:blue;}',
    '.bold-text{color:grey;}',
    '.small-text{color:red;font-style:italic;}'
  ]
})


export class AppComponent {
  
color:string
backgroundcolor:string
constructor() { 
    this.color = 'blue';
    this.backgroundcolor = 'pink';
  }
  
  

}